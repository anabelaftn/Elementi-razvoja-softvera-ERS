# Dva naloga

 
 Ako vidite dva naloga na moje ime, sa 2 laptopa radim, a nece ovaj jedan nalog stari laptop da mi prihvati. Anabela
 
